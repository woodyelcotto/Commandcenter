# Install Package
sudo apt update
sudo apt install realvnc-vnc-server
sudo apt install xscreensaver

# Copy auto Start
cp ./autostart /home/pi/.config/lxsession/LXDE-pi/

# Enable SSH
sudo systemctl enable ssh
sudo systemctl start ssh

# Enable VNC
sudo systemctl enable vncserver-x11-serviced.service
sudo systemctl start vncserver-x11-serviced.service

hostname -I

# Open rpi config
sudo raspi-config

# Chromium
chromium-browser "https://chrome.google.com/webstore/detail/tab-rotate/pjgjpabbgnnoohijnillgbckikfkbjed?hl=th"

