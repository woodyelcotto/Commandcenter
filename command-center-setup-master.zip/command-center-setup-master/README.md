# command-center-setup

## Setup
- Clone from master SD Card
- Config WI-FI
- Setup config URL